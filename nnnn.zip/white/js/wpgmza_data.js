(function(){}());// This file is used for localization and will be deprecated in the future

function __wpgmzaMapEngineLoadedCallback(){
	/* This doesn't do anything for the moment, it's just to meet google requirements
	 * Our initialziation is handled internally so this is purely for the spec 
	 * 
	 * Long term, we'll probably allow this to be used a trigger though, for lazy loading, or something similar 
	 */
}